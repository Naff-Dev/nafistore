<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nafistore</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body class="bg-gray-800 text-white">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <!-- Header and Navigation -->
        <nav class="flex gap-4 mb-6">
            <button
                class="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                aria-current="page">
                Produk
            </button>
        </nav>

        <form method="POST" action="/transaksi/create" id="orderForm" class="space-y-8">
            <!-- Step 1: Product Selection -->
            <section aria-labelledby="step-1-heading">
                <h2 id="step-1-heading" class="bg-blue-600 text-white p-4 rounded-lg mb-4 flex items-center">
                    <span class="bg-blue-700 px-3 py-1 rounded-full mr-2">1</span>
                    Pilih Nominal
                </h2>

                <!-- Products Grid -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4" role="radiogroup" aria-label="Pilihan Produk">
                    <?php foreach ($produk as $p): ?>
                    <div class="product-card group relative border-2 rounded-lg p-4 cursor-pointer transition-colors hover:bg-gray-700"
                        data-product-id="<?= $p->kode; ?>" data-product-name="<?= $p->nama; ?>"
                        data-product-price="<?= $p->harga; ?>" role="radio" tabindex="0">
                        <input type="radio" name="product_id" class="sr-only" value="<?= $p->kode; ?>" required>
                        <div class="flex justify-between items-center">
                            <div>
                                <div class="text-white font-semibold"><?= $p->nama; ?></div>
                                <input type="hidden" name="harga" value="<?= $p->harga; ?>">
                                <div class="text-white">Rp. <?= number_format($p->harga, 0, ',', '.'); ?></div>
                            </div>
                            <div class="text-2xl">💎</div>
                        </div>
                        <div class="check-icon hidden absolute top-2 right-2 text-blue-500">
                            <i class="fas fa-check-circle" aria-hidden="true"></i>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Step 2: Account Details -->
            <section aria-labelledby="step-2-heading">
                <h2 id="step-2-heading"
                    class="bg-blue-600 text-white p-4 rounded-lg mb-4 flex items-center justify-between">
                    <div>
                        <span class="bg-blue-700 px-3 py-1 rounded-full mr-2">2</span>
                        Masukan Detail Akun
                    </div>
                    <button type="button" class="text-white hover:text-gray-200 focus:outline-none"
                        aria-label="Informasi Detail Akun" data-tooltip="Klik untuk informasi lebih lanjut">
                        <i class="fas fa-question-circle"></i>
                    </button>
                </h2>

                <div class="bg-gray-800 text-white p-6 rounded-lg">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="tujuan" class="block mb-2">Tujuan</label>
                            <input type="text" id="tujuan" name="tujuan"
                                class="w-full p-2 rounded bg-gray-700 border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                placeholder="Masukan Tujuan" required>
                        </div>
                    </div>
                    <p class="text-gray-400 mt-4 text-sm">
                        Untuk Mobile Legends Id & Server Ditulis langsung tanpa spasi, Untuk Sosial Media Pastikan Link
                        Target Sesuai
                    </p>
                </div>
            </section>

            <!-- Step 3: Payment Method -->
            <section aria-labelledby="step-3-heading">
                <h2 id="step-3-heading" class="bg-blue-600 text-white p-4 rounded-lg mb-4">
                    <span class="bg-blue-700 px-3 py-1 rounded-full mr-2">3</span>
                    Pilih Pembayaran
                </h2>

                <div class="space-y-4">
                    <!-- Order Summary -->
                    <div class="bg-gray-800 text-white p-4 rounded-lg">
                        <h3 class="text-lg font-semibold mb-2">Detail Pembayaran</h3>
                        <div class="flex justify-between items-center">
                            <div id="selectedProductName" class="text-gray-300">Pilih produk terlebih dahulu</div>
                            <div id="selectedProductPrice" class="font-semibold">Rp. 0</div>
                        </div>
                    </div>

                    <!-- Payment Options -->
                    <div class="space-y-4" role="radiogroup" aria-label="Metode Pembayaran">
                        <label class="block bg-gray-800 p-4 rounded-lg hover:bg-gray-700 cursor-pointer">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <input type="radio" name="payment_method" value="qris"
                                        class="text-blue-600 focus:ring-blue-500" required>
                                    <span class="font-medium">QRIS (BISA SEMUA PEMBAYARAN)</span>
                                </div>
                            </div>
                        </label>


                    </div>
                </div>
            </section>

            <!-- Submit Button -->
            <div class="text-center">
                <button type="submit"
                    class="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed">
                    Lanjutkan Pembayaran
                </button>
            </div>
        </form>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const productsContainer = document.querySelector('.grid');
        const productCards = document.querySelectorAll('.product-card');

        productCards.forEach(card => {
            card.addEventListener('click', () => selectProduct(card));
            card.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    selectProduct(card);
                }
            });
        });
    });

    function selectProduct(card) {
        // Deselect all product cards and remove active styles
        document.querySelectorAll('.product-card').forEach(c => {
            c.classList.remove('bg-blue-50', 'border-blue-500');
            c.classList.add('bg-gray-800', 'border-transparent');
            c.querySelector('.check-icon').classList.add('hidden');
            c.setAttribute('aria-checked', 'false');
            c.querySelector('input').checked = false;
        });

        // Select the clicked product card and apply active styles
        card.classList.add('bg-blue-50', 'border-blue-500');
        card.classList.remove('bg-gray-800', 'border-transparent');
        card.setAttribute('aria-checked', 'true');
        card.querySelector('.check-icon').classList.remove('hidden');
        card.querySelector('input').checked = true;

        // Get product name and price from data attributes
        const productName = card.getAttribute('data-product-name');
        const productPrice = card.getAttribute('data-product-price');

        // Display selected product name and price
        document.getElementById('selectedProductName').textContent = productName;
        document.getElementById('selectedProductPrice').textContent = 'Rp. ' + parseInt(productPrice).toLocaleString(
            'id-ID');
    }
    </script>
</body>

</html>