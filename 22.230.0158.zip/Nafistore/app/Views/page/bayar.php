<!DOCTYPE html>
<html lang="en">

<head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description"
        content="Payment gateway indonesia. Aplikasi pembayaran dengan pilihan metode Virtual Account, QRIS, Indomaret, Alfamart, E-Wallet, E-Banking dll.">
    <meta name="keywords"
        content="Payment gateway, Virtual Account, QRIS, Indomaret, Alfamart, E-Wallet, E-Banking dll">
    <meta name="author" content="7hwID">
    <title>Nafi Store</title>
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="https://paydisini.co.id/assets/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <!-- Vendors styles-->
    <link rel="stylesheet" href="https://paydisini.co.id/vendors/simplebar/css/simplebar.css">
    <link rel="stylesheet" href="https://paydisini.co.id/css/vendors/simplebar.css">
    <!-- Main styles for this application-->
    <link href="https://paydisini.co.id/css/style.css" rel="stylesheet">
    <!-- We use those styles to show code examples, you should remove them in your application.-->
    <script src="https://paydisini.co.id/js/sweetalert2.all.min.js"></script>
    <link href="https://paydisini.co.id/vendors/@coreui/icons/css/brand.min.css" rel="stylesheet">
    <link href="//cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <link href="https://paydisini.co.id/payment/css/style.css" rel="stylesheet">
    <link href="https://paydisini.co.id/payment/css/checkout.css" rel="stylesheet">
</head>

<body>
    <img src="https://paydisini.co.id/payment/images/background-2.jpg" id="bg" alt="">
    <br />
    <div class="min-vh-100 d-flex flex-row align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card-group d-block d-md-flex row">
                        <div class="card col-md-5 text-white bg-primary py-5">
                            <div class="card-body text-center">
                                <div>
                                    <h5>Pembayaran dengan <b>QRIS</b></h5>
                                    <p><small style="font-style: italic;">Pastikan anda melakukan pembayaran sebelum
                                            melewati batas waktu pembayaran dan dengan nominal yang tepat.</small></p>
                                    <p><a class="fancybox"
                                            href="https://paydisini.co.id/payment/qrcode.php?unique_code=981f05e5cdc8eef09559779e7278ac0c&merchant=3"><img
                                                src="https://paydisini.co.id/payment/qrcode.php?unique_code=981f05e5cdc8eef09559779e7278ac0c&merchant=3"
                                                style="width:100%;max-width:180px !important;cursor:zoom-in"
                                                id="qr_code" /></a></p>
                                    <small style="font-style: italic;">* Klik untuk memperbesar kode QR</small>
                                    <button class="btn btn-primary btn-outline-light mt-3"
                                        id="payment_instruction_button" data-toggle="modal"
                                        data-target="#cara_bayar">Cara Pembayaran</button>
                                </div>
                            </div>
                        </div>
                        <div class="card col-md-7 p-4 mb-0">
                            <div class="card-body">
                                <!--<div class="float-left">
                    <a target="_blank" href="https://paydisini.co.id/"><img src="https://paydisini.co.id/assets/paydisini.png" style="height:100%;max-height:30px"></a>
                  </div>-->
                                <div class="text-right">
                                    <img src="https://paydisini.co.id/payment/images/qris.png"
                                        style="height:100%;max-height:30px">
                                </div>
                                <div class="alert alert-light">
                                    <h5 style="text-align: center;"><b>PT Disini Digital</b></h5>
                                </div>
                                <span class="payment__title"></span>
                                <div class="mb-3 input-group form-floating">
                                    <input type="text" class="form-control border-right-0" id="noReferensi"
                                        data-toggle="tooltip" title="Berhasil menyalin teks" value="TRX12345"
                                        aria-describedby="inputGroupPrepend" disabled readonly style="background: #fff">
                                    <button class="btn btn-outline-secondary" data-toggle="tooltip" data-placement="top"
                                        title="Salin" onclick="copy('TRX12345')" type="button"><i
                                            class="fa fa-copy"></i></button>
                                    <label for="floatingInputValue">No. Tagihan</label>
                                </div>
                                <div class="mb-3 input-group form-floating">
                                    <input type="text" class="form-control border-right-0" id="noReferensi"
                                        data-toggle="tooltip" title="Berhasil menyalin teks" value="Rp 18.000,00"
                                        aria-describedby="inputGroupPrepend" disabled readonly style="background: #fff">
                                    <button class="btn btn-outline-secondary" data-toggle="modal"
                                        data-target="#detail_pembayaran" type="button"><i
                                            class="fa fa-question-circle"></i></button>
                                    <label for="floatingInputValue">Total Tagihan</label>
                                </div>
                                <div class="mb-3 form-floating">
                                    <input type="text" class="form-control" id="noReferensi" data-toggle="tooltip"
                                        title="Berhasil menyalin teks" value="2023-12-04 10:05:46 WIB"
                                        aria-describedby="inputGroupPrepend" disabled readonly style="background: #fff">
                                    <label for="floatingInputValue">Batas Pembayaran</label>
                                </div>
                                <div class="text-right"><a href="https://paydisini.co.id"><button id="back_to_merchant"
                                            class="btn btn-info btn-outline-light right" type="button"><span
                                                class="fa fa-arrow-left fz-20 m-r-15"></span> Kembali ke
                                            Merchant</button></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex">
                <div class="m-auto pb-2" style="margin-top: 55px !important;font-size: 14px;">
                    <div class="alert alert-light"><b>Secure Payment by <a href="https://paydisini.co.id/"
                                target="_blank"><img src="https://paydisini.co.id/assets/paydisini.png"
                                    style="height: 20px; margin-left: 7px;" alt="Paydisini"></a></b></div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="detail_pembayaran" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true" style="padding-left:0px !important; z-index: 99999;">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document" style>
            <div class="modal-content" style="border-radius: 0px;">
                <div class="modal-header shadow-sm" style="padding:20px 16px; z-index: 9999;">
                    <h3 class="modal-title" id="exampleModalLabel"
                        style="font-weight: bold; font-size: 16px; color:#003366;">Detail Pembayaran</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="outline: none;">
                        <span aria-hidden="true" class="fa fa-times"></span>
                    </button>
                </div>
                <div class="modal-body teks shadow-sm"
                    style="background-color: rgba(7, 38, 241, 0.04); padding: 0px 16px;">
                    <div class="row mid-dtl justify-content-center">
                        <div class="col-6 col-sm-6 merchant-logo" style="padding-right: 0px;">
                            <ul class="align-middle text-center" style="margin:20px 0px;">
                                <li><img id="merchantLogo" src="https://paydisini.co.id/assets/icon.png" alt="Logo" />
                                </li>
                                <li><span><span id="labelMerchantNameDetail" class="shopname" style="font-size:13px;">PT
                                            Disini Digital</span></span></li>
                            </ul>
                        </div>
                        <div class="col-6 col-sm-6 text-left" style="padding-top:20px; padding-bottom: 20px;">
                            <ul style="margin-bottom: 0px;">
                                <li><span>No. Tagihan</span></li>
                                <li><span id="labelOrderId"
                                        style="font-size:10px;display:inline-block;margin-bottom:.5rem;font-weight:normal">TRX12345</span>
                                </li>
                                <li>
                                    <hr style="margin-bottom: 20px; margin-top: 0px;" />
                                </li>
                            </ul>
                            <ul style="margin-bottom: 0px;">
                                <li><span>Tanggal Transaksi</span></li>
                                <li><span id="labelTransactionDate"
                                        style="font-size:13px;display:inline-block;margin-bottom:.5rem;font-weight:normal">2023-12-04
                                        10:05:46</span></li>
                                <li>
                                    <hr style="margin-bottom: 0px; margin-top: 0px;" />
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="modal-price">
                    <div class="row">
                        <div class="col-6 col-md-6 text-left" style="padding-right:0px;">
                            <span>Biaya</span>
                        </div>
                        <div class="col-6 col-md-6 text-right" style="padding-left:0px;">
                            <span><span id="labelBasedAmount" class="pgname">Rp 18.000,00</span></span>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-6 col-md-6 text-left" style="padding-right:0px;">
                            <span>Biaya Layanan</span>
                        </div>
                        <div class="col-6 col-md-6 text-right" style="padding-left:0px;">
                            <span><span id="labelFeeAmount" class="pgname">Rp 0,00</span></span>
                        </div>
                    </div>
                    <hr />
                </div>
                <div class="modal-total">
                    <div class="row">
                        <div class="col-6 col-md-6 text-left" style="padding-right:0px;">
                            <h4>Total Biaya</h4>
                        </div>
                        <div class="col-6 col-md-6 text-right" style="padding-left:0px;">
                            <h4><span id="labelAmount" class="pgname">Rp 18.000,00</span></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade lg" id="cara_bayar" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <div class="modal-title" id="cara_bayar_title">
                        <div class="d-flex flex-row">
                            <div class="d-flex align-items-center">
                                <img src="https://paydisini.co.id/payment/images/qris.png" width="auto" height="20px">
                            </div>
                            <div class="ml-3 title-pembayaran">
                                Petunjuk Pembayaran QRIS </div>
                        </div>
                    </div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>


                <div class="modal-body pt-0 pr-0 pl-0 mt-0">

                    <div id="payment-modal" class="custom-accordion">
                        <div class="card custom-padding-accordion">
                            <div class="card-header payment-instruction-head" id="payment-instruction-head-0">
                                <h5 class="mb-0">
                                    <span class="btn collaped panel-title" data-toggle="collapse"
                                        data-target="#payment-instruction-collapse-0" aria-expanded="true"
                                        aria-controls="payment-instruction-collapse-0">Langkah pembayaran dengan
                                        QRIS</span>
                                </h5>
                            </div>
                            <div id="payment-instruction-collapse-0" class="collapse show custom-padding-accordion-2"
                                aria-labelledby="payment-instruction-head-0" data-parent="#payment-modal">
                                <div class="card-body">
                                    <ol class="list-petunjuk-pembayaran">
                                        <li>Buka aplikasi yang mendukung pembayaran dengan QRIS</li>
                                        <li>Pilih fitur QRIS / Bayar</li>
                                        <li>Pindai kode QR yang diberikan oleh Merchant</li>
                                        <li>Pastikan tagihan yang ditagihkan sesuai</li>
                                        <li>Klik tombol Konfirmasi</li>
                                        <li>Masukkan PIN untuk menyelesaikan pembayaran</li>
                                        <li>Setelah pembayaran berhasil, kamu akan dialihkan ke Halaman Hasil Pembayaran
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <!-- CoreUI and necessary plugins-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js">
    </script>
    <script src="https://paydisini.co.id/vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <script src="https://paydisini.co.id/vendors/simplebar/js/simplebar.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script>
    $(document).ready(function() {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(".fancybox").fancybox();

    });

    function startLoader(element = null, text = null) {
        var msg = '<div class="lds-dual-ring"></div>';
        if (text != null) {
            msg +=
                '<br/><br><span class="loader-text" style="font-size:[font_size]px;color:gainsboro;font-weight:500">' +
                text + '</span>';
        }

        var screenWidth = $(window).width();
        var screenHeight = $(window).height();

        if (element != null) {
            var elementWidth = $(element).width();
            var elementHeight = $(element).height();

            var fontSize = (elementWidth * 0.035).toFixed(1);
            fontSize = fontSize > 20 ? 20 : fontSize;
            var imgWidth = ((elementWidth * elementHeight) * 0.0003).toFixed(1);
            imgWidth = imgWidth > 100 ? 100 : imgWidth;

            msg = msg.replace('[max_image_width]', imgWidth);
            msg = msg.replace('[font_size]', fontSize);

            var loaderHeight = (elementHeight / 2) - 15;
            loaderHeight = loaderHeight.toFixed(1);
            if (text != null) {
                loaderHeight = loaderHeight - 20;
            }

            $(element).block({
                css: {
                    border: 'none',
                    top: loaderHeight + 'px',
                    backgroundColor: 'transparent',
                    'z-index': 10000
                },
                message: msg
            });
            $(".blockOverlay").css('z-index', 9999);
        } else {
            var fontSize = (screenWidth * 0.035).toFixed(1);
            fontSize = fontSize > 20 ? 20 : fontSize;
            var imgWidth = ((screenWidth * screenHeight) * 0.0003).toFixed(1);
            imgWidth = imgWidth > 100 ? 100 : imgWidth;

            msg = msg.replace('[max_image_width]', imgWidth);
            msg = msg.replace('[font_size]', fontSize);

            var loaderHeight = (screenHeight / 2) - 15;
            loaderHeight = loaderHeight.toFixed(1);
            if (text != null) {
                loaderHeight = loaderHeight - 20;
            }

            $.blockUI({
                css: {
                    border: 'none',
                    top: loaderHeight + 'px',
                    backgroundColor: 'transparent',
                    'z-index': 10000
                },
                message: msg
            });
            $(".blockOverlay").css('z-index', 9999);
        }
    }

    function stopLoader(element = null) {
        if (element != null) {
            $(element).unblock();
        } else {
            $.unblockUI();
        }
    }

    function loaderText(text, element = null) {
        if (element != null) {
            $(element).find('.loader-text').text(text);
        } else {
            $('.loader-text').text(text);
        }
    }

    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-full-width",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "100",
        "hideDuration": "100",
        "timeOut": "2000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };

    $(function() {
        $('[data-toggle="tooltip"]').tooltip();

        window.cs = setInterval(checkStatus, 15 * 1000,
            'eyJ1bmlxdWVfY29kZSI6Ijk4MWYwNWU1Y2RjOGVlZjA5NTU5Nzc5ZTcyNzhhYzBjIiwibWVyY2hhbnQiOjN9');

        $('img#qr_code').on('load', function() {
            console.log("OK");
        });
    });

    function copy(text) {
        navigator.clipboard.writeText(text).then(function() {
            toastr.success('Teks berhasil disalin');
        }, function(err) {
            toastr.error('Teks gagal disalin');
        });
    }

    function returnToMerchant() {
        window.open('https://irvankedesmm.co.id/deposit', '_self');
    }

    function checkStatus(reference, showLoader = false) {
        if (showLoader === true) {
            startLoader();
        }

        $.ajax({
            url: "https://paydisini.co.id/payment/status.php",
            type: "POST",
            dataType: "JSON",
            data: {
                reference: reference
            },
            success: function(s) {
                if (showLoader === true) {
                    stopLoader();
                }

                var sp = '';
                //{"status":"UNPAID","paid_at":null}
                if (s.status == "PAID") {
                    clearInterval(window.cs);
                    $('#payment_instruction_button').remove();
                    $('#back_to_merchant').remove();
                    toastr.success('Transaksi ini sudah berhasil dibayar pada!');

                    var timeLeft = 2;
                    var arm = setInterval(function() {
                        if (timeLeft <= 0) {
                            returnToMerchant();
                            clearInterval(arm);
                        } else {
                            timeLeft -= 1;
                            $('#auto-redirect').text('(' + timeLeft + ')');
                        }
                    }, 1000);

                } else if (s.status == 'FAILED' || s.status == 'REFUND') {
                    clearInterval(window.cs);
                    $('#payment_instruction_button').remove();
                    $('#back_to_merchant').remove();
                    toastr.error('Transaksi gagal!');

                } else if (s.status == 'EXPIRED') {
                    clearInterval(window.cs);
                    $('#payment_instruction_button').remove();
                    $('#back_to_merchant').remove();
                    toastr.error('Transaksi kadaluarsa!');
                }

                $('.payment__title').prepend(sp);
            },
            error: function() {
                if (showLoader === true) {
                    stopLoader();
                }
            }
        });
    }
    </script>

</body>

</html>