<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\Kategori;
use App\Models\SubKategori;
use App\Models\Produk;

class Categori extends BaseController
{
    protected $kategori;
    protected $sub;
    protected $Produk;

    public function __construct(){
        $this->kategori = new Kategori();
        $this->sub = new SubKategori();
        $this->produk = new Produk();
    }

    public function index()
    {
        $data = [
            'kategori'=> $this->kategori->where('status', 1)->findall(),
            'sub'=> $this->sub->findAll(),
        ];

        return view('index',$data);
    }


    public function kategori($kode){
        $data = [
            'kategori'=> $this->kategori->where('status', 1 )->findall(),
            'sub'=> $this->sub->where('kd_kategori', $kode )->findAll(),
        ];

        return view('index',$data);
    }

    public function Produk($kode){
        $data = [
            'produk'=> $this->produk->where('sub_kode', $kode )->findAll(),
        ];

        return view('page/produk',$data);
    }
}
