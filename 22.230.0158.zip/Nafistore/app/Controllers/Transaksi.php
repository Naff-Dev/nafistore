<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\Kategori;
use App\Models\SubKategori;
use App\Models\Produk;
use App\Models\TransaksiModel;
use Rudaz\Paydisini\Paydisini;


class Transaksi extends BaseController
{
    protected $kategori;
    protected $sub;
    protected $Produk;

    public function __construct(){
        $this->paydisini = new Paydisini(); 
        $this->paydisini->config(['apiKey' => '44abfc0118194bc52231f0c820f491f5']);
        $this->kategori = new Kategori();
        $this->sub = new SubKategori();
        $this->produk = new Produk();
        $this->transaksi = new TransaksiModel();
    }

    public function index()
    {
        // Tangkap data dari form
        $kodeProduk = $this->request->getVar('product_id');
        $tujuan = $this->request->getVar('tujuan');
        $pembayaran = $this->request->getVar('payment_method');
        $harga = $this->request->getVar('harga'); // Fungsi untuk mendapatkan harga berdasarkan kode produk

        // Generate kode transaksi unik
        $kodeTrx = 'trx-' . time();

        $response = $this->paydisini->transaction([
            'unique_code' => $kodeTrx ,
            'service' => 11,
            'amount' =>  $harga,
            'note' => 'Produk  ' . $kodeProduk. ' Tujuan'. $tujuan,
            'valid_time' => 300 * 3,
            'ewallet_phone' => 'Nomor_telpon_customer',
            'type_fee' => '1',
            'return_url' => 'http://localhost:8080/riwayat',
            ]);

            if ($response['success']) {
                // Redirect to checkout URL
                $dataTransaksi = [
                    'user_id' => session()->get('user_id'),
                    'kode_trx' => $kodeTrx,
                    'kode_produk' => $kodeProduk,
                    'tujuan' => $tujuan,
                    'harga' => $harga,
                    'status' => 0,  // Atur status awal transaksi
                    'pembayaran' => $pembayaran,
                    'link'=> $response['data']['checkout_url_beta'],
                    'tanggal_trx' => date('Y-m-d H:i:s')
                ];
        
                // Simpan data ke dalam database
                $transaksiModel = new TransaksiModel();
                $transaksiModel->insert($dataTransaksi);
                return redirect()->to($response['data']['checkout_url_beta']);
            } else {
                // Handle error
                return redirect()->to('/error')->with('message', $response['msg']);
            }


      
       
      
    }

    public function batal(){
        $this->paydisini->cancelTransaction([
            'unique_code' => 'trx-1730378548'
            ]);
    }

    public function callback()
    {
        $this->paydisini->callback([
            'unique_code' => '1234',
            'status' => 'Success'
            ]);
    }
    public function channel()
{
    $chanel = $this->paydisini->chanel();

    // Menampilkan hasil sebagai JSON
    return $this->response->setJSON($chanel);
}


public function riwayat()
{
    // Ambil semua riwayat transaksi berdasarkan user_id yang tersimpan dalam session
    $riwayat = $this->transaksi->where('user_id', session()->get('user_id'))->findAll();

    // Kirim data riwayat ke view
    $data = [
        'riwayat' => $riwayat
    ];

    return view('page/riwayat', $data);
}




    
}