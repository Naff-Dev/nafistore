<?php

namespace App\Controllers;
use App\Models\User;

class Home extends BaseController
{

    protected $user;

    public function __construct(){
        $this->user = new User();
       
    }
    public function Login()
    {
        return view('page/login');
    }
    public function register()
    {
        return view('page/register');
    }
    
    public function login_proses()
    {
        // Ambil input username dan password
    $username = $this->request->getPost('username');
    $password = $this->request->getPost('password');

    // Cek apakah pengguna dengan username yang diberikan ada di database
    $user = $this->user->where('username', $username)->first();
    
    // Jika pengguna ditemukan dan password cocok
    if ($user && password_verify($password, $user->password)) {
        // Set session untuk menandai pengguna sebagai login
        session()->set([
            'IsLoggedIn' => TRUE,
            'username' => $user->username,
            'user_id' => $user->id
        ]);
        
        // Arahkan ke halaman utama atau dashboard
        return redirect()->to('/');
    } else {
        // Jika login gagal, tampilkan pesan kesalahan
        return redirect()->back()->with('error', 'Username atau password salah.');
    }
}

public function register_proses()
{
    $nama = $this->request->getPost('nama');
    $username = $this->request->getPost('username');
    $password = $this->request->getPost('password');
    $email = $this->request->getPost('email');
    $nohp = $this->request->getPost('nohp');

    // Hash password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Insert data into the database
    $inserted = $this->user->insert([
        'nama' => $nama,
        'username' => $username,
        'password' => $password_hash,
        'email' => $email,
        'nohp' => $nohp
    ]);

    // Check if insertion was successful
    if ($inserted) {
        return redirect()->to('/login')->with('success', 'Registrasi berhasil. Silakan login.');
    } else {
        return redirect()->back()->with('error', 'Registrasi gagal. Coba lagi.');
    }
}

}
