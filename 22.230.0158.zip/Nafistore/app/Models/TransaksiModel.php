<?php

namespace App\Models;

use CodeIgniter\Model;

class TransaksiModel extends Model
{
    protected $table            = 'Transaksi';
    protected $primaryKey       = 'id';
    protected $returnType       = 'object';
    protected $allowedFields    = ['id', 'user_id','kode_trx', 'kode_produk', 'tujuan', 'harga', 'status', 'pembayaran', 'tanggal_trx'];

    
}
