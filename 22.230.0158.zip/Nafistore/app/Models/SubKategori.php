<?php

namespace App\Models;

use CodeIgniter\Model;

class SubKategori extends Model
{
    protected $table            = 'sub_kategori';
    protected $primaryKey       = 'id';
    protected $returnType       = 'object';
    protected $allowedFields    = ['nama','kode','kd_kategori','gambar'];

   
}
