<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Categori::index', ['filter' => 'auth']);
$routes->get('/categori/(:any)', 'Categori::kategori/$1');
$routes->get('/produk/(:any)', 'Categori::produk/$1');
$routes->get('/channel', 'Transaksi::channel');
$routes->get('/batal', 'Transaksi::batal');
$routes->get('/riwayat', 'Transaksi::riwayat', ['filter' => 'auth']);

$routes->get('/login', 'Home::Login');
$routes->get('/register', 'Home::Register');

$routes->post('/login', 'Home::login_proses');
$routes->post('/register', 'Home::register_proses');



$routes->post('/transaksi/create', 'Transaksi::index', ['filter' => 'auth']);
$routes->post('/transaksi/callback', 'Transaksi::callback');